# OrangeHRM Employee Lifecycle — Selenium + Java + TestNG

## Scope
This starter framework follows the supplied assessment workflow:
1. Login and verify Dashboard.
2. Add an employee from CSV data and optionally upload `profile.png`.
3. Search by Employee ID and update Job Title and Employment Status.
4. Optionally validate employee data through an authorized API endpoint.
5. Delete the employee and verify it is absent from the employee list.
6. Logout and verify the login form.

## Requirements
- JDK 17 or later
- Maven 3.9+
- Google Chrome
- Eclipse/IntelliJ (optional)

## Setup
1. Import this folder as an **Existing Maven Project**.
2. Open `src/test/resources/config.properties`.
3. Verify the demo URL and use only currently authorized credentials. The assignment PDF did not specify credentials; the values included here are common demo defaults and may change.
4. Edit `src/test/resources/employee-data.csv`.
5. Optional profile image: add a valid image named `profile.png` in `src/test/resources/`.
6. In Eclipse, right-click the project → Maven → Update Project.

## Run
From the project root:
```bash
mvn clean test
```
The Chrome driver is managed by Selenium Manager in standard Selenium 4 setups.

## Output
- HTML report: `reports/ExtentReport.html`
- Failure screenshots: `screenshots/`
- TestNG output: `target/surefire-reports/`

## API validation caveat
The supplied assessment asks for API validation, but it does not give an API endpoint, authentication method, or response schema. The framework does not invent these. Set `apiBaseUrl` and (if required) `apiBearerToken` only for an endpoint you are authorized to use, and update the route in `EmployeeApiClient.java` to match its documented contract. The sample test validates the HTTP success status and employee ID only; strengthen it to compare name/job/status fields after confirming the response schema.

## Video recording
Selenium does not record video natively. Record the run using an approved desktop screen recorder, or configure a compatible Selenium Grid/video-recording service. The assessment asks for a video, so include a short successful run recording with your submission.

## Important locator note
OrangeHRM is a live demo application and its UI can change. Before submission, run the test and adjust locators in the Page Object classes to the current page structure. Do not run destructive tests against a shared/production tenant without permission.
