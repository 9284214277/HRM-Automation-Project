# Test Cases — OrangeHRM Employee Lifecycle

| ID | Area | Scenario | Expected result | Group |
|---|---|---|---|---|
| TC-LOGIN-01 | Authentication | Admin logs in with valid credentials | Dashboard is displayed | smoke, regression |
| TC-LOGIN-02 | Authentication | Admin logs in with invalid password | Dashboard is not displayed | regression |
| TC-ROLE-01 | Authorization | ESS account logs in | Dashboard is displayed and restricted menus are absent per configured policy | role |
| TC-PIM-01 | Employee | Create a unique employee | Employee can be found by its generated ID | regression, e2e |
| TC-PIM-02 | Employee | Update job title and employment status and assert the selected dropdown values | Updated values remain selected | regression, e2e |\n| TC-API-01 | API | Read employee by ID through authorized OrangeHRM API | HTTP success and employee ID in response | api |
| TC-LOGOUT-01 | Authentication | User logs out | Login form is displayed | smoke, regression |

## Test data
Employee names and IDs are generated for each run to reduce collisions. Optional profile image:
`src/test/resources/profile.png`.

## Environment requirements
- `-Denv=demo` loads `config-demo.properties`.
- `-Denv=qa` loads `config-qa.properties`.
- Configure ESS credentials and API authentication only for an authorized tenant.
- API path and response schema must be confirmed against the actual tenant's API documentation before treating the API case as fully validated.

## Known scope limitations
The supplied assessment feedback calls for Admin-vs-ESS permission checks and API verification of the exact UI-created employee. The current starter has an ESS menu-visibility test and a configurable API read test, but the demo environment supplied no ESS credentials or API auth contract. Those tests will be skipped until valid environment credentials and API details are supplied. The create test performs UI verification and cleanup. A complete create-update-read-delete API cross-check needs a confirmed API contract and permission to use it.
