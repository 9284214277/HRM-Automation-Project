package base;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import utilities.ExtentManager;
import utilities.ScreenshotUtil;

public class BaseTest {
	 protected WebDriver driver;

	    protected Properties config = new Properties();

	    @BeforeMethod
	    public void setUp() {

	        try {

	            // Read config.properties
	            FileInputStream input =
	                    new FileInputStream("src/test/resources/config.properties");

	            config.load(input);

	            input.close();

	            // Open Chrome
	            driver = new ChromeDriver();

	            // Maximize browser
	            driver.manage().window().maximize();

	            // Open application
	            driver.get(config.getProperty("baseUrl"));

	        } catch (Exception e) {

	            e.printStackTrace();
	        }
	    }
    @AfterMethod(alwaysRun = true)
    public void tearDown(ITestResult result) {
        try {
        	if (result.getStatus() == ITestResult.FAILURE) {

                ScreenshotUtil.takeScreenshot(driver, result.getName());
            }
             else if (result.getStatus() == ITestResult.SUCCESS) {
                ExtentManager.pass("Test passed");
            } else {
                ExtentManager.skip("Test skipped");
            }
        } finally {
            if (driver != null) {
                driver.quit();
            }
            ExtentManager.flush();
        }
    }
}
