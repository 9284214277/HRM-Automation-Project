package pages;

import java.time.Duration;

import org.jspecify.annotations.Nullable;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PimPage {
    private final WebDriver driver;
    private final WebDriverWait wait;
    private String createdEmployeeId;

    private final By pimMenu = By.xpath("//span[normalize-space()='PIM']");
    private final By addEmployeeMenu = By.xpath("//a[normalize-space()='Add Employee']");
    private final By firstName = By.name("firstName");
    private final By middleName = By.name("middleName");
    private final By lastName = By.name("lastName");
    private final By employeeId = By.xpath("//label[normalize-space()='Employee Id']/ancestor::div[contains(@class,'oxd-input-group')]//input");
    private final By saveButton = By.xpath("//*[@type='submit']");
    private final By successToast = By.cssSelector(".oxd-toast--success");
    private final By employeeListMenu = By.xpath("//a[normalize-space()='Employee List']");
    private final By searchEmployeeId = By.xpath("//label[normalize-space()='Employee Id']/ancestor::div[contains(@class,'oxd-input-group')]//input");
    private final By searchButton = By.xpath("//button[normalize-space()='Search']");
    private final By tableRows = By.cssSelector(".oxd-table-body .oxd-table-card");
    private final By editButtons = By.cssSelector(".oxd-table-body .oxd-table-card button");

    public PimPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(20));
    }

    public void openAddEmployee() {
        try {
            wait.until(ExpectedConditions.elementToBeClickable(pimMenu)).click();

            wait.until(ExpectedConditions.elementToBeClickable(addEmployeeMenu)).click();

            wait.until(ExpectedConditions.visibilityOfElementLocated(firstName));

            System.out.println("Add Employee page opened successfully.");

        } catch (Exception e) {
            System.out.println("Failed to open Add Employee page: " + e.getMessage());
            throw e;
        }
    }

    public String addEmployee(String first, String last, String photoPath) {
        try {
            wait.until(ExpectedConditions.visibilityOfElementLocated(firstName))
                    .sendKeys(first);

            driver.findElement(lastName).sendKeys(last);

            WebElement idInput = wait.until(
                    ExpectedConditions.visibilityOfElementLocated(employeeId));

            if (photoPath != null && !photoPath.isBlank()) {
                By photoInput = By.cssSelector("input[type='file']");

                if (!driver.findElements(photoInput).isEmpty()) {
                    driver.findElement(photoInput).sendKeys(photoPath);
                }
            }

            // Capture Employee ID before clicking Save
            createdEmployeeId = idInput.getAttribute("value");

            // Wait until the form loader disappears
            By loader = By.cssSelector(".oxd-form-loader");

            wait.until(ExpectedConditions.invisibilityOfElementLocated(loader));

            // Click Save
            WebElement clickOnSave = wait.until(
                    ExpectedConditions.elementToBeClickable(saveButton));

            clickOnSave.click();

            // Wait for successful navigation or success message
            wait.until(ExpectedConditions.or(
                    ExpectedConditions.visibilityOfElementLocated(
                            By.xpath("//h6[contains(normalize-space(),'Personal Details')]")),
                    ExpectedConditions.visibilityOfElementLocated(successToast)));

            System.out.println(
                    "Employee added successfully. ID: " + createdEmployeeId);

            return createdEmployeeId;

        } catch (Exception e) {
            System.out.println("Failed to add employee: " + e.getMessage());
            throw e;
        }
    }
    
    

    public boolean isEmployeeSaved() {
        return !driver.findElements(By.xpath("//h6[contains(normalize-space(),'Personal Details')]")).isEmpty()
                || !driver.findElements(successToast).isEmpty();
    }

    public void openEmployeeList() {
        try {
            wait.until(ExpectedConditions.elementToBeClickable(pimMenu)).click();

            // Wait for the Employee List page to load
            wait.until(ExpectedConditions.visibilityOfElementLocated(searchButton));

            System.out.println("Employee List page opened successfully.");

        } catch (Exception e) {
            System.out.println("Failed to open Employee List page: " + e);
            throw e;
        }
    }

    public boolean searchEmployee() {
        WebElement idInput = wait.until(ExpectedConditions.visibilityOfElementLocated(searchEmployeeId));
        idInput.clear();
        idInput.sendKeys(createdEmployeeId);
        driver.findElement(searchButton).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".oxd-table-body")));
        return driver.findElements(tableRows).stream()
                .anyMatch(row -> row.getText().contains(createdEmployeeId));
    }

    public void clickFirstEditResult() {
        try {
            WebElement row = wait.until(
                ExpectedConditions.visibilityOfElementLocated(tableRows));

            row.findElement(By.cssSelector("button")).click();

            wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//h6[contains(normalize-space(),'Personal Details')]")));

            System.out.println("Edit button clicked successfully.");

        } catch (Exception e) {
            System.out.println("Failed to click Edit button: " + e.getMessage());
            throw e;
        }
    }

    public void deleteEmployeeById() {
        try {
            // Open employee list and search for the created employee
            openEmployeeList();
            Thread.sleep(3000);
            searchEmployee();

            WebElement targetRow = wait.until(d -> d.findElements(tableRows).stream()
                    .filter(r -> r.getText().contains(createdEmployeeId))
                    .findFirst()
                    .orElse(null));

            // Select employee checkbox
            //targetRow.findElement(By.cssSelector("input[type='checkbox']")).click();

            // Click Delete Selected
            By deleteSelected = By.xpath("//*[@role='row']//button[@type='button']/i[contains(@class,'bi-trash')]");
            wait.until(ExpectedConditions.elementToBeClickable(deleteSelected)).click();

            // Confirm deletion
            By confirmDelete = By.xpath("//button[normalize-space()='Yes, Delete']");
            wait.until(ExpectedConditions.elementToBeClickable(confirmDelete)).click();

            // Wait until the employee row disappears
            wait.until(ExpectedConditions.invisibilityOf(targetRow));

            System.out.println("Employee deleted successfully: " + createdEmployeeId);

        } catch (Exception e) {
            System.out.println("Failed to delete employee: " + e.getMessage());
            
        }
    }
}
