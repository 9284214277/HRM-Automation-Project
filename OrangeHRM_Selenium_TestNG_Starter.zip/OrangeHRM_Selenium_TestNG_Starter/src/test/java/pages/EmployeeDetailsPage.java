package pages;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class EmployeeDetailsPage {
	private final WebDriver driver;
	private final WebDriverWait wait;

	private final By jobTab = By.xpath("//a[normalize-space()='Job']");
	private final By saveButton = By.cssSelector("button[type='submit']");

	public EmployeeDetailsPage(WebDriver driver) {
		this.driver = driver;
		this.wait = new WebDriverWait(driver, Duration.ofSeconds(20));
	}

	public void updateJobDetails(String jobTitle, String employmentStatus) {
		try {
			wait.until(ExpectedConditions.elementToBeClickable(jobTab)).click();
			Thread.sleep(3000);

			chooseCustomDropdown("Job Title", jobTitle);
			chooseCustomDropdown("Employment Status", employmentStatus);

			wait.until(ExpectedConditions.elementToBeClickable(saveButton)).click();

			wait.until(ExpectedConditions.or(
					ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".oxd-toast--success")),
					ExpectedConditions
							.visibilityOfElementLocated(By.xpath("//h6[contains(normalize-space(),'Job Details')]"))));

			System.out.println("Job details updated successfully.");

		} catch (Exception e) {
			System.out.println(e);
			
		}
	}

	public void chooseCustomDropdown(String label, String value) {
		try {
			By dropdown = By.xpath(
					"//label[normalize-space()='" + label + "']/ancestor::div[contains(@class,'oxd-input-group')]//div[contains(@class,'oxd-select-text')]/i");
			wait.until(ExpectedConditions.elementToBeClickable(dropdown)).click();

			By option = By.xpath("//div[@role='option']//span[normalize-space()='" + value + "']");

			wait.until(ExpectedConditions.elementToBeClickable(option)).click();

		} catch (Exception e) {
			System.out.println("Failed to select " + label + " value '" + value + "': " + e.getMessage());
			throw e;
		}
	}
}
