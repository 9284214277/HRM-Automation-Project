package pages;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.BaseTest;

public class LoginPage extends BaseTest {
	private final WebDriver driver;
	private final WebDriverWait wait;

	private final By username = By.name("username");
	private final By password = By.name("password");
	private final By loginButton = By.xpath("//*[@type='submit']");
	private final By dashboardHeading = By.xpath("//h6[normalize-space()='Dashboard']");
	private final By userMenu = By.cssSelector("p.oxd-userdropdown-name");
	private final By logoutLink = By.xpath("//a[normalize-space()='Logout']");

	public LoginPage(WebDriver driver) {
		this.driver = driver;
		this.wait = new WebDriverWait(driver, Duration.ofSeconds(20));
	}

	public void login(String user, String pass) {
		WebElement UserElement =wait.until(ExpectedConditions.visibilityOfElementLocated(username));
		UserElement.clear();
		UserElement.sendKeys(user);
		WebElement PassElement =driver.findElement(password);
		PassElement.clear();
		PassElement.sendKeys(pass);
		driver.findElement(loginButton).click();
	}

	public void isDashboardVisible(String HomePageName) {
		try {
			WebElement Menu = wait.until(ExpectedConditions.visibilityOfElementLocated(dashboardHeading));
			String text = Menu.getText();
			if (text.equalsIgnoreCase(HomePageName)) {
				System.out.println("Dashboard is visible");
			} else {
				System.out.println("Dashboard name does not match");
			}

		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public void logout() {
		wait.until(ExpectedConditions.elementToBeClickable(userMenu)).click();
		wait.until(ExpectedConditions.elementToBeClickable(logoutLink)).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(username));
	}

	public boolean isLoginPageVisible() {
		return !driver.findElements(username).isEmpty();
	}
}
