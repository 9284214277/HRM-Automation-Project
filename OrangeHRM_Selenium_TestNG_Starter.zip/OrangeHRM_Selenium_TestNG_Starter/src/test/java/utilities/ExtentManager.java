package utilities;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public final class ExtentManager {
    private static ExtentReports report;
    private static ExtentTest test;
    private static final String REPORT_PATH = "reports/ExtentReport.html";

    private ExtentManager() {}

    private static synchronized ExtentReports getReport() {
        if (report == null) {
            java.io.File folder = new java.io.File("reports");
            if (!folder.exists()) folder.mkdirs();
            ExtentSparkReporter spark = new ExtentSparkReporter(REPORT_PATH);
            spark.config().setDocumentTitle("OrangeHRM Automation Report");
            spark.config().setReportName("Employee Lifecycle E2E");
            report = new ExtentReports();
            report.attachReporter(spark);
            report.setSystemInfo("Framework", "Selenium + Java + TestNG");
        }
        return report;
    }

    public static synchronized void startTest(String name) {
        test = getReport().createTest(name);
    }

    public static synchronized void pass(String message) {
        if (test != null) test.pass(message);
    }

    public static synchronized void fail(String message) {
        if (test != null) test.fail(message);
    }

    public static synchronized void skip(String message) {
        if (test != null) test.skip(message);
    }

    public static synchronized void info(String message) {
        if (test != null) test.info(message);
    }

    public static synchronized void attachScreenshot(String absolutePath) {
        try {
            if (test != null) test.addScreenCaptureFromPath(absolutePath);
        } catch (Exception e) {
            if (test != null) test.warning("Could not attach screenshot: " + e.getMessage());
        }
    }

    public static synchronized void flush() {
        if (report != null) report.flush();
    }
}
