package utilities;

import java.io.FileInputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public final class EmployeeDataReader {

    private EmployeeDataReader() {}

    public static String[] readFirstEmployeeRow() {

        try {
            FileInputStream fis = new FileInputStream(
                    "src/test/resources/employee-data.csv");

            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(fis));

            reader.readLine(); // Skip header

            String line = reader.readLine();

            reader.close();

            String[] data = line.split(",", -1);

            return data;

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}