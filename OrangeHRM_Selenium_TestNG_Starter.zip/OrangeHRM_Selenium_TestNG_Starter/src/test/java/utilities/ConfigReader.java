package utilities;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public final class ConfigReader {
    private static final Properties PROPERTIES = new Properties();
    static {
        String env = System.getProperty("env", "demo");
        String path = "src/test/resources/config-" + env + ".properties";
        try (FileInputStream input = new FileInputStream(path)) {
            PROPERTIES.load(input);
        } catch (IOException e) {
            throw new ExceptionInInitializerError("Cannot load " + path + ": " + e.getMessage());
        }
    }
    private ConfigReader() {}
    public static String get(String key) { return PROPERTIES.getProperty(key, "").trim(); }
    public static String get(String key, String defaultValue) {
        String value = get(key);
        return value.isEmpty() ? defaultValue : value;
    }
}
