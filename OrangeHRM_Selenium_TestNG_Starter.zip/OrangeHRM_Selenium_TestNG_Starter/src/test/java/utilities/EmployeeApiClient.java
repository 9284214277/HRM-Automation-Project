package utilities;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import java.util.Properties;

public final class EmployeeApiClient {
    private EmployeeApiClient() {}

    public static Response getEmployee(String employeeId, Properties config) {
        String baseUrl = config.getProperty("apiBaseUrl", "").trim();
        String token = config.getProperty("apiBearerToken", "").trim();

        if (baseUrl.isEmpty()) {
            throw new IllegalStateException(
                "API validation is not configured. Set apiBaseUrl to your authorized employee API endpoint.");
        }

        var request = RestAssured
        		.given()
        		.baseUri(baseUrl)
        		.accept("application/json");
        if (!token.isEmpty()) request.header("Authorization", "Bearer " + token);

        // Replace this route only after confirming the endpoint contract for your environment.
        return request.get("/employees/" + employeeId);
    }
}
