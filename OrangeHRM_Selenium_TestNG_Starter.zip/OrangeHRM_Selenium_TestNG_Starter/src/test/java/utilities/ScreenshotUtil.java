package utilities;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public final class ScreenshotUtil {
    private ScreenshotUtil() {}

    public static String takeScreenshot(WebDriver driver, String testName) {
        if (driver == null) return null;
        try {
            File folder = new File("screenshots");
            if (!folder.exists()) folder.mkdirs();

            String time = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
            String safeName = testName.replaceAll("[^a-zA-Z0-9_-]", "_");
            File source = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            File destination = new File(folder, safeName + "_" + time + ".png");
            FileUtils.copyFile(source, destination);

            System.out.println("Screenshot saved: " + destination.getAbsolutePath());
            return destination.getAbsolutePath();
        } catch (Exception e) {
            System.err.println("Could not save screenshot: " + e.getMessage());
            return null;
        }
    }
}
