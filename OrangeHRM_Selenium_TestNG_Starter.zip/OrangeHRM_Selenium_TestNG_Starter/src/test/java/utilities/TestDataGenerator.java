package utilities;

import java.util.UUID;

public final class TestDataGenerator {
    private TestDataGenerator() {}
    public static String uniqueLastName(String prefix) {
        return prefix + UUID.randomUUID().toString().replace("-", "").substring(0, 6);
    }
    public static String employeeId() {
        return String.valueOf(10000 + (int)(Math.random() * 89999));
    }
}
