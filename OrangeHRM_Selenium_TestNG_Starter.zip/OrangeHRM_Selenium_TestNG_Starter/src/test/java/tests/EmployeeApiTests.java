package tests;

import base.BaseTest;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.Test;
import utilities.ConfigReader;
import utilities.EmployeeApiClient;

public class EmployeeApiTests extends BaseTest {
    @Test(groups={"api"})
    public void employeeEndpointReturnsAuthorizedResponse() {
        String base = ConfigReader.get("api.baseUrl");
        String id = ConfigReader.get("api.employeeId");
        if (base.isEmpty() || id.isEmpty()) {
            throw new SkipException("Set api.baseUrl and api.employeeId for your authorized OrangeHRM API environment.");
        }
        Response response = EmployeeApiClient.getEmployee(id,config);
        Assert.assertTrue(response.statusCode() >= 200 && response.statusCode() < 300,
                "Expected successful employee API response but received " + response.statusCode());
        Assert.assertTrue(response.asString().contains(id), "Response should contain requested employee ID.");
    }
}
