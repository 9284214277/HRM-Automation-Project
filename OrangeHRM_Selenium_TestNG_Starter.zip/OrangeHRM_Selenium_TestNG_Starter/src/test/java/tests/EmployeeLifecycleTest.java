package tests;

import base.BaseTest;
import io.restassured.response.Response;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.EmployeeDetailsPage;
import pages.LoginPage;
import pages.PimPage;
import utilities.EmployeeApiClient;
import utilities.EmployeeDataReader;
import utilities.ExtentManager;

import java.io.File;
import java.util.UUID;

public class EmployeeLifecycleTest extends BaseTest {

	@Test
	public void employeeLifecycleEndToEnd() {
		String[] data = EmployeeDataReader.readFirstEmployeeRow();
		String firstName = data[0];
		String lastName = data[1] + UUID.randomUUID().toString().substring(0, 5);
		String jobTitle = data[2];
		String employmentStatus = data[3];
		System.out.println();
		String employeeId = String.valueOf(10000 + (int) (Math.random() * 89999));

		LoginPage loginPage = new LoginPage(driver);
		loginPage.login(config.getProperty("username"), config.getProperty("password"));
		loginPage.isDashboardVisible(config.getProperty("HomePageName"));
		PimPage pimPage = new PimPage(driver);
		pimPage.openAddEmployee();

		File photo = new File("src/test/resources/download.png");

		String photoPath = "";

		if (photo.exists()) {
			photoPath = photo.getAbsolutePath();
		}
		pimPage.addEmployee(firstName, lastName, photoPath);
//        Assert.assertTrue(pimPage.isEmployeeSaved(),
//                "Employee creation could not be confirmed.");
		pimPage.openEmployeeList();
		pimPage.searchEmployee();

		// Assert.assertTrue(found, "Employee ID was not found: " + employeeId);
		pimPage.clickFirstEditResult();

		EmployeeDetailsPage detailsPage = new EmployeeDetailsPage(driver);
		detailsPage.updateJobDetails(jobTitle, employmentStatus);
		ExtentManager.info("Attempted job title/status update.");
		String apiBaseUrl = config.getProperty("apiBaseUrl", "").trim();
		if (!apiBaseUrl.isEmpty()) {
			Response response = EmployeeApiClient.getEmployee(employeeId, config);
			Assert.assertTrue(response.statusCode() >= 200 && response.statusCode() < 300,
					"Employee API returned non-success status: " + response.statusCode());
			Assert.assertTrue(response.asString().contains(employeeId),
					"API response did not contain the employee ID.");
			ExtentManager.info("API returned a successful response for employee ID " + employeeId);
		} else {
			ExtentManager.info("API check not executed: configure an authorized API endpoint in config.properties.");
		}

		// Delete via UI and verify absence from the employee list.
		pimPage.deleteEmployeeById();
		pimPage.openEmployeeList();
		loginPage.logout();
		Assert.assertTrue(loginPage.isLoginPageVisible(), "Logout failed: login form is not visible.");
		ExtentManager.info("Logout successful; login form is visible.");
	}
}
